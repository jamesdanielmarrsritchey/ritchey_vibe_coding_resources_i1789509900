# Changelog

## v0.11
- Added consistent print-friendly RML styling independent of the active screen theme.
- Added an optional alternative print stylesheet for easy instance customization.
- Corrected Get Date-Time capitalization in Navigation.
- Removed unused old logo versions.
- Updated current-release metadata throughout the project.

## v0.10
- Centered the Landing-page FAQ heading.
- Added a theme-aware image overlay gradient and over-image Publish button styling.
- Corrected Get Date-Time capitalization.
- Updated current-release metadata throughout the project.

## v0.9
- Restored the stable Navigation-page return-header presentation.
- Added Landing to the Pages section.
- Removed visitor-facing uses of the redirect bypass query parameter.
- Added and adopted a transparent corrected logo asset.

## v0.8
- Normalized every HTML page to Ritchey HTML Formatting Scheme v1 section/content/holder structure.
- Added the privately-operated information footer and local definition asset.
- Added a corrected v2 logo while retaining the original as logo-v1.jpg.
- Hid all headers and footers during printing and excluded View-page download controls.
- Fixed widget table hover coverage.
- Added View-page RML and compressed-content downloads.
- Added the image-based Landing page with FAQ content.
- Added configurable index-to-landing redirect behavior.
- Updated current release metadata throughout the project.

## v0.7
- Refined Navigation ordering and conditional Return-header behavior.
- Added the reusable site logo.
- Updated homepage and Publish-page wording.
- Added one-click checksum copying and the Get Date-time widget.
- Replaced public-instance Legal content with the example Legal-page text and demonstration notice.
- Updated copyright structure and current-release metadata.

## v0.6
- Renamed Legal.html to legal.html and updated references.
- Removed the theme-header divider line.
- Standardized robots.txt for unrestricted crawling.
- Added the dependency-free Hash Strings widget.
- Added Tools, Meta, and Miscellaneous groups to Navigation.
- Added About and Hello World.txt items.
- Restored the original project-template CONTRIBUTE.md.
- Updated current release metadata throughout the project.

## v0.5
- Separated Return to Parent, Theme, and Site Name/Navigation into three header bands.
- Standardized shared layout width at 90% across portrait and landscape screens.
- Added Navigation-page conditional back-button heading.
- Renamed publication actions to Publish and View.
- Added manual content-parameter entry on the View page when no parameter is present.
- Refined reusable theme icons and responsive layout behavior.
- Updated current release metadata throughout the project.

## v0.4
- Rebuilt the shared theme from the supplied reference project's responsive structure.
- Added Return to Parent and reference-style Navigation return behavior.
- Added reliable SVG theme icons and moved the theme switcher into the main header.
- Removed header taglines.
- Matched portrait/landscape width and button behavior more closely.
- Reorganized footer legal links and split reusable theme CSS from app-specific CSS.
- Updated current release metadata throughout the project.

## v0.3
- Theme button now shows the theme that clicking will activate.
- Theme button uses moon/sun icons only, with opposite-theme styling.
- Improved Navigation-page theme-control contrast.
- Standardized Navigation-page button dimensions.
- Corrected current-version metadata throughout the project.

## v0.2
- Reworked the light and night themes based on the supplied example web project.
- Updated buttons, navigation, typography, page surfaces, footer, and return-to-top styling.
- Kept the existing RML parsing and publishing functionality unchanged.

## v0.1
- Initial release.
