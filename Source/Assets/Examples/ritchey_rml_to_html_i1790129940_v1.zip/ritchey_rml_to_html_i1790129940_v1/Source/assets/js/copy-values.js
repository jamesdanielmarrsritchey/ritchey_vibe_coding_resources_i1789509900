/* Description: Provides a dependency-free clipboard helper for reusable copy-value controls. */
(function () {
    "use strict";

    function fun_1e7ab492_fallback_copy_i1790130040_v1(var_1e7ab492_text_str) {
        var var_1e7ab492_textarea_obj = document.createElement("textarea");
        var var_1e7ab492_success_bool = false;
        var_1e7ab492_textarea_obj.value = var_1e7ab492_text_str;
        var_1e7ab492_textarea_obj.setAttribute("readonly", "readonly");
        var_1e7ab492_textarea_obj.style.position = "fixed";
        var_1e7ab492_textarea_obj.style.left = "-9999px";
        document.body.appendChild(var_1e7ab492_textarea_obj);
        var_1e7ab492_textarea_obj.focus();
        var_1e7ab492_textarea_obj.select();
        try {
            var_1e7ab492_success_bool = document.execCommand("copy") === true;
        } catch (var_1e7ab492_error_obj) {
            var_1e7ab492_success_bool = false;
        }
        document.body.removeChild(var_1e7ab492_textarea_obj);
        return var_1e7ab492_success_bool;
    }

    function fun_1e7ab492_copy_text_i1790130041_v1(var_1e7ab492_text_str, var_1e7ab492_success_fun, var_1e7ab492_failure_fun) {
        function fun_1e7ab492_use_fallback_i1790130042_v1() {
            if (fun_1e7ab492_fallback_copy_i1790130040_v1(var_1e7ab492_text_str) === true) {
                if (typeof var_1e7ab492_success_fun === "function") { var_1e7ab492_success_fun(); }
            } else if (typeof var_1e7ab492_failure_fun === "function") {
                var_1e7ab492_failure_fun();
            }
        }
        if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
            navigator.clipboard.writeText(var_1e7ab492_text_str).then(function () {
                if (typeof var_1e7ab492_success_fun === "function") { var_1e7ab492_success_fun(); }
            }).catch(fun_1e7ab492_use_fallback_i1790130042_v1);
            return;
        }
        fun_1e7ab492_use_fallback_i1790130042_v1();
    }

    window.RitcheyClipboard = { copyText: fun_1e7ab492_copy_text_i1790130041_v1 };
}());
