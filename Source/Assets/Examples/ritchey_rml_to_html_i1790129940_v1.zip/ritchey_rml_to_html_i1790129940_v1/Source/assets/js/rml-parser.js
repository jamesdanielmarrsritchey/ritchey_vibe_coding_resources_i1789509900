/* Description: Converts Ritchey Markup Language v5 into escaped, browser-safe HTML without third-party dependencies. */
(function (var_4f8c2a71_global_obj) {
    "use strict";

    /* Description: Escapes text before it is inserted into generated HTML. */
    function fun_4f8c2a71_escape_html_i1790129952_v1(var_4f8c2a71_text_str) {
        return String(var_4f8c2a71_text_str)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    /* Description: Escapes a value for use inside a quoted HTML attribute. */
    function fun_4f8c2a71_escape_attribute_i1790129953_v1(var_4f8c2a71_text_str) {
        return fun_4f8c2a71_escape_html_i1790129952_v1(var_4f8c2a71_text_str).replace(/`/g, "&#96;");
    }

    /* Description: Makes source comments safe for insertion as HTML comments. */
    function fun_4f8c2a71_make_html_comment_safe_i1790129954_v1(var_4f8c2a71_text_str) {
        var var_4f8c2a71_safe_str = String(var_4f8c2a71_text_str).replace(/--/g, "- -");
        if (var_4f8c2a71_safe_str.endsWith("-") === true) {
            var_4f8c2a71_safe_str += " ";
        }
        return var_4f8c2a71_safe_str;
    }

    /* Description: Accepts image references allowed by RML while rejecting active script/data protocols. */
    function fun_4f8c2a71_sanitize_image_source_i1790129955_v1(var_4f8c2a71_source_str) {
        var var_4f8c2a71_trimmed_str = String(var_4f8c2a71_source_str).trim();
        var var_4f8c2a71_lower_str = var_4f8c2a71_trimmed_str.toLowerCase();
        if (var_4f8c2a71_trimmed_str === "") {
            return "";
        }
        if (var_4f8c2a71_lower_str.startsWith("javascript:") === true || var_4f8c2a71_lower_str.startsWith("data:") === true || var_4f8c2a71_lower_str.startsWith("vbscript:") === true) {
            return "";
        }
        return var_4f8c2a71_trimmed_str;
    }

    /* Description: Accepts hyperlinks demonstrated by RML examples while rejecting non-HTTP protocols. */
    function fun_4f8c2a71_sanitize_link_i1790129956_v1(var_4f8c2a71_link_str) {
        var var_4f8c2a71_trimmed_str = String(var_4f8c2a71_link_str).trim();
        if (/^https?:\/\//i.test(var_4f8c2a71_trimmed_str) === true) {
            return var_4f8c2a71_trimmed_str;
        }
        return "";
    }

    /* Description: Applies only the four supported simple STYLE values. */
    function fun_4f8c2a71_apply_styles_i1790129957_v1(var_4f8c2a71_html_str, var_4f8c2a71_styles_str) {
        var var_4f8c2a71_parts_arr = var_4f8c2a71_styles_str.split(",");
        var var_4f8c2a71_index_num = 0;
        var var_4f8c2a71_style_str = "";
        var var_4f8c2a71_result_str = var_4f8c2a71_html_str;
        while (var_4f8c2a71_index_num < var_4f8c2a71_parts_arr.length) {
            var_4f8c2a71_style_str = var_4f8c2a71_parts_arr[var_4f8c2a71_index_num].trim().toLowerCase();
            if (var_4f8c2a71_style_str === "bold") {
                var_4f8c2a71_result_str = "<strong>" + var_4f8c2a71_result_str + "</strong>";
            } else if (var_4f8c2a71_style_str === "italic" || var_4f8c2a71_style_str === "italics") {
                var_4f8c2a71_result_str = "<em>" + var_4f8c2a71_result_str + "</em>";
            } else if (var_4f8c2a71_style_str === "underlined" || var_4f8c2a71_style_str === "underline") {
                var_4f8c2a71_result_str = "<span class=\"rml_underline\">" + var_4f8c2a71_result_str + "</span>";
            } else if (var_4f8c2a71_style_str === "strikethrough" || var_4f8c2a71_style_str === "strike through") {
                var_4f8c2a71_result_str = "<s>" + var_4f8c2a71_result_str + "</s>";
            }
            var_4f8c2a71_index_num += 1;
        }
        return var_4f8c2a71_result_str;
    }

    /* Description: Converts a special RML comment into a visibly styled span, including the requested status colours. */
    function fun_4f8c2a71_render_special_comment_i1790129958_v1(var_4f8c2a71_comment_str) {
        var var_4f8c2a71_upper_str = var_4f8c2a71_comment_str.trim().toUpperCase();
        var var_4f8c2a71_class_str = "rml_special_comment";
        if (var_4f8c2a71_upper_str === "EXPIRED") {
            var_4f8c2a71_class_str += " rml_special_comment_expired";
        } else if (var_4f8c2a71_upper_str === "ISSUED") {
            var_4f8c2a71_class_str += " rml_special_comment_issued";
        } else if (var_4f8c2a71_upper_str === "RENEWED") {
            var_4f8c2a71_class_str += " rml_special_comment_renewed";
        } else if (var_4f8c2a71_upper_str === "EXPIRING") {
            var_4f8c2a71_class_str += " rml_special_comment_expiring";
        } else if (var_4f8c2a71_upper_str === "PREFERRED") {
            var_4f8c2a71_class_str += " rml_special_comment_preferred";
        }
        return "<span class=\"" + var_4f8c2a71_class_str + "\">(" + fun_4f8c2a71_escape_html_i1790129952_v1(var_4f8c2a71_comment_str) + ")</span>";
    }

    /* Description: Parses inline images, simple STYLE selectors, links, special comments, and tabs from one compatible text value. */
    function fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_text_str) {
        var var_4f8c2a71_result_str = "";
        var var_4f8c2a71_index_num = 0;
        var var_4f8c2a71_close_num = -1;
        var var_4f8c2a71_after_num = 0;
        var var_4f8c2a71_selector_str = "";
        var var_4f8c2a71_comment_str = "";
        var var_4f8c2a71_source_str = "";
        var var_4f8c2a71_safe_str = "";
        var var_4f8c2a71_url_str = "";
        var var_4f8c2a71_style_end_num = -1;
        var var_4f8c2a71_link_start_num = -1;
        var var_4f8c2a71_special_end_num = -1;
        while (var_4f8c2a71_index_num < var_4f8c2a71_text_str.length) {
            if (var_4f8c2a71_text_str.slice(var_4f8c2a71_index_num, var_4f8c2a71_index_num + 8) === "(IMAGE: ") {
                var_4f8c2a71_close_num = var_4f8c2a71_text_str.indexOf(")", var_4f8c2a71_index_num + 8);
                if (var_4f8c2a71_close_num !== -1) {
                    var_4f8c2a71_source_str = var_4f8c2a71_text_str.slice(var_4f8c2a71_index_num + 8, var_4f8c2a71_close_num);
                    var_4f8c2a71_safe_str = fun_4f8c2a71_sanitize_image_source_i1790129955_v1(var_4f8c2a71_source_str);
                    if (var_4f8c2a71_safe_str !== "") {
                        var_4f8c2a71_result_str += "<img class=\"rml_image\" src=\"" + fun_4f8c2a71_escape_attribute_i1790129953_v1(var_4f8c2a71_safe_str) + "\" alt=\"\">";
                    } else {
                        var_4f8c2a71_result_str += fun_4f8c2a71_escape_html_i1790129952_v1(var_4f8c2a71_text_str.slice(var_4f8c2a71_index_num, var_4f8c2a71_close_num + 1));
                    }
                    var_4f8c2a71_index_num = var_4f8c2a71_close_num + 1;
                    continue;
                }
            }
            if (var_4f8c2a71_text_str.charAt(var_4f8c2a71_index_num) === "{") {
                var_4f8c2a71_close_num = var_4f8c2a71_text_str.indexOf("}", var_4f8c2a71_index_num + 1);
                if (var_4f8c2a71_close_num !== -1) {
                    var_4f8c2a71_selector_str = var_4f8c2a71_text_str.slice(var_4f8c2a71_index_num + 1, var_4f8c2a71_close_num);
                    var_4f8c2a71_after_num = var_4f8c2a71_close_num + 1;
                    if (var_4f8c2a71_text_str.slice(var_4f8c2a71_after_num, var_4f8c2a71_after_num + 9) === " (STYLE: ") {
                        var_4f8c2a71_style_end_num = var_4f8c2a71_text_str.indexOf(")", var_4f8c2a71_after_num + 9);
                        if (var_4f8c2a71_style_end_num !== -1) {
                            var_4f8c2a71_comment_str = var_4f8c2a71_text_str.slice(var_4f8c2a71_after_num + 9, var_4f8c2a71_style_end_num);
                            var_4f8c2a71_result_str += fun_4f8c2a71_apply_styles_i1790129957_v1(fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_selector_str), var_4f8c2a71_comment_str);
                            var_4f8c2a71_index_num = var_4f8c2a71_style_end_num + 1;
                            continue;
                        }
                    }
                    var_4f8c2a71_link_start_num = var_4f8c2a71_after_num;
                    if (var_4f8c2a71_text_str.charAt(var_4f8c2a71_link_start_num) === " ") {
                        var_4f8c2a71_link_start_num += 1;
                    }
                    if (var_4f8c2a71_text_str.charAt(var_4f8c2a71_link_start_num) === "(") {
                        var_4f8c2a71_special_end_num = var_4f8c2a71_text_str.indexOf(")", var_4f8c2a71_link_start_num + 1);
                        if (var_4f8c2a71_special_end_num !== -1) {
                            var_4f8c2a71_url_str = var_4f8c2a71_text_str.slice(var_4f8c2a71_link_start_num + 1, var_4f8c2a71_special_end_num);
                            var_4f8c2a71_safe_str = fun_4f8c2a71_sanitize_link_i1790129956_v1(var_4f8c2a71_url_str);
                            if (var_4f8c2a71_safe_str !== "") {
                                var_4f8c2a71_result_str += "<a href=\"" + fun_4f8c2a71_escape_attribute_i1790129953_v1(var_4f8c2a71_safe_str) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_selector_str) + "</a>";
                                var_4f8c2a71_index_num = var_4f8c2a71_special_end_num + 1;
                                continue;
                            }
                        }
                    }
                }
            }
            if (var_4f8c2a71_text_str.charAt(var_4f8c2a71_index_num) === "(") {
                var_4f8c2a71_special_end_num = var_4f8c2a71_text_str.indexOf(")", var_4f8c2a71_index_num + 1);
                if (var_4f8c2a71_special_end_num !== -1) {
                    var_4f8c2a71_comment_str = var_4f8c2a71_text_str.slice(var_4f8c2a71_index_num + 1, var_4f8c2a71_special_end_num);
                    if (var_4f8c2a71_comment_str !== "" && /[a-z]/.test(var_4f8c2a71_comment_str) === false) {
                        var_4f8c2a71_result_str += fun_4f8c2a71_render_special_comment_i1790129958_v1(var_4f8c2a71_comment_str);
                        var_4f8c2a71_index_num = var_4f8c2a71_special_end_num + 1;
                        continue;
                    }
                }
            }
            if (var_4f8c2a71_text_str.charAt(var_4f8c2a71_index_num) === "\t") {
                var_4f8c2a71_result_str += "<span class=\"rml_tab\">&#9;</span>";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            var_4f8c2a71_result_str += fun_4f8c2a71_escape_html_i1790129952_v1(var_4f8c2a71_text_str.charAt(var_4f8c2a71_index_num));
            var_4f8c2a71_index_num += 1;
        }
        return var_4f8c2a71_result_str;
    }

    /* Description: Determines whether a line is a dot-list or numbered-list entry and returns its parsed parts. */
    function fun_4f8c2a71_get_list_line_i1790129960_v1(var_4f8c2a71_line_str) {
        var var_4f8c2a71_match_arr = var_4f8c2a71_line_str.match(/^( *)(- |([0-9]+)\. )(.*)$/);
        if (var_4f8c2a71_match_arr === null) {
            return null;
        }
        return {
            indent: var_4f8c2a71_match_arr[1].length,
            type: var_4f8c2a71_match_arr[3] === undefined ? "ul" : "ol",
            text: var_4f8c2a71_match_arr[4]
        };
    }

    /* Description: Checks whether list text meets the strict RML list-label rule. */
    function fun_4f8c2a71_is_list_label_i1790129961_v1(var_4f8c2a71_text_str) {
        return var_4f8c2a71_text_str.endsWith(":") === true && /[a-z]/.test(var_4f8c2a71_text_str) === false;
    }

    /* Description: Recursively renders a list level according to increases and decreases in leading-space indentation. */
    function fun_4f8c2a71_render_list_level_i1790129962_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_start_num, var_4f8c2a71_end_num, var_4f8c2a71_indent_num, var_4f8c2a71_type_str) {
        var var_4f8c2a71_html_str = "<" + var_4f8c2a71_type_str + ">";
        var var_4f8c2a71_index_num = var_4f8c2a71_start_num;
        var var_4f8c2a71_item_obj = null;
        var var_4f8c2a71_next_obj = null;
        var var_4f8c2a71_nested_obj = null;
        var var_4f8c2a71_class_str = "";
        while (var_4f8c2a71_index_num < var_4f8c2a71_end_num) {
            var_4f8c2a71_item_obj = fun_4f8c2a71_get_list_line_i1790129960_v1(var_4f8c2a71_lines_arr[var_4f8c2a71_index_num]);
            if (var_4f8c2a71_item_obj === null || var_4f8c2a71_item_obj.indent < var_4f8c2a71_indent_num || (var_4f8c2a71_item_obj.indent === var_4f8c2a71_indent_num && var_4f8c2a71_item_obj.type !== var_4f8c2a71_type_str)) {
                break;
            }
            if (var_4f8c2a71_item_obj.indent > var_4f8c2a71_indent_num) {
                break;
            }
            var_4f8c2a71_class_str = fun_4f8c2a71_is_list_label_i1790129961_v1(var_4f8c2a71_item_obj.text) === true ? " class=\"rml_list_label\"" : "";
            var_4f8c2a71_html_str += "<li" + var_4f8c2a71_class_str + ">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_item_obj.text);
            var_4f8c2a71_index_num += 1;
            if (var_4f8c2a71_index_num < var_4f8c2a71_end_num) {
                var_4f8c2a71_next_obj = fun_4f8c2a71_get_list_line_i1790129960_v1(var_4f8c2a71_lines_arr[var_4f8c2a71_index_num]);
                if (var_4f8c2a71_next_obj !== null && var_4f8c2a71_next_obj.indent > var_4f8c2a71_indent_num) {
                    var_4f8c2a71_nested_obj = fun_4f8c2a71_render_list_level_i1790129962_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_index_num, var_4f8c2a71_end_num, var_4f8c2a71_next_obj.indent, var_4f8c2a71_next_obj.type);
                    var_4f8c2a71_html_str += var_4f8c2a71_nested_obj.html;
                    var_4f8c2a71_index_num = var_4f8c2a71_nested_obj.next;
                }
            }
            var_4f8c2a71_html_str += "</li>";
        }
        var_4f8c2a71_html_str += "</" + var_4f8c2a71_type_str + ">";
        return {html: var_4f8c2a71_html_str, next: var_4f8c2a71_index_num};
    }

    /* Description: Renders consecutive dot/numbered list lines, including nested indentation. */
    function fun_4f8c2a71_render_list_i1790129963_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_start_num, var_4f8c2a71_end_num) {
        var var_4f8c2a71_first_obj = fun_4f8c2a71_get_list_line_i1790129960_v1(var_4f8c2a71_lines_arr[var_4f8c2a71_start_num]);
        return fun_4f8c2a71_render_list_level_i1790129962_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_start_num, var_4f8c2a71_end_num, var_4f8c2a71_first_obj.indent, var_4f8c2a71_first_obj.type);
    }

    /* Description: Splits one flat-list line into inline-capable list items. */
    function fun_4f8c2a71_render_flat_list_i1790129964_v1(var_4f8c2a71_line_str) {
        var var_4f8c2a71_inner_str = var_4f8c2a71_line_str.slice(2, -2);
        var var_4f8c2a71_items_arr = var_4f8c2a71_inner_str.split(" | ");
        var var_4f8c2a71_html_str = "<ul class=\"rml_flat_list\">";
        var var_4f8c2a71_index_num = 0;
        while (var_4f8c2a71_index_num < var_4f8c2a71_items_arr.length) {
            var_4f8c2a71_html_str += "<li>" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_items_arr[var_4f8c2a71_index_num]) + "</li>";
            var_4f8c2a71_index_num += 1;
        }
        return var_4f8c2a71_html_str + "</ul>";
    }

    /* Description: Renders one or more consecutive RML table rows, processing inline markup in every cell. */
    function fun_4f8c2a71_render_table_i1790129965_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_start_num, var_4f8c2a71_end_num) {
        var var_4f8c2a71_html_str = "<div class=\"rml_table_wrapper\"><table class=\"rml_table\"><tbody>";
        var var_4f8c2a71_index_num = var_4f8c2a71_start_num;
        var var_4f8c2a71_inner_str = "";
        var var_4f8c2a71_cells_arr = null;
        var var_4f8c2a71_cell_num = 0;
        var var_4f8c2a71_cell_str = "";
        var var_4f8c2a71_left_trimmed_str = "";
        var var_4f8c2a71_is_heading_boo = false;
        while (var_4f8c2a71_index_num < var_4f8c2a71_end_num && /^\|\| .* \|\|$/.test(var_4f8c2a71_lines_arr[var_4f8c2a71_index_num]) === true) {
            var_4f8c2a71_inner_str = var_4f8c2a71_lines_arr[var_4f8c2a71_index_num].slice(3, -3);
            var_4f8c2a71_cells_arr = var_4f8c2a71_inner_str.split(" || ");
            var_4f8c2a71_html_str += "<tr>";
            var_4f8c2a71_cell_num = 0;
            while (var_4f8c2a71_cell_num < var_4f8c2a71_cells_arr.length) {
                var_4f8c2a71_cell_str = var_4f8c2a71_cells_arr[var_4f8c2a71_cell_num];
                var_4f8c2a71_left_trimmed_str = var_4f8c2a71_cell_str.replace(/^\s+/, "");
                var_4f8c2a71_is_heading_boo = var_4f8c2a71_left_trimmed_str.charAt(0) === "#" && var_4f8c2a71_left_trimmed_str.charAt(1) !== " ";
                if (var_4f8c2a71_is_heading_boo === true) {
                    var_4f8c2a71_cell_str = var_4f8c2a71_left_trimmed_str.slice(1).trimEnd();
                    var_4f8c2a71_html_str += "<th>" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_cell_str) + "</th>";
                } else {
                    var_4f8c2a71_cell_str = var_4f8c2a71_cell_str.trim();
                    var_4f8c2a71_html_str += "<td>" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_cell_str) + "</td>";
                }
                var_4f8c2a71_cell_num += 1;
            }
            var_4f8c2a71_html_str += "</tr>";
            var_4f8c2a71_index_num += 1;
        }
        var_4f8c2a71_html_str += "</tbody></table></div>";
        return {html: var_4f8c2a71_html_str, next: var_4f8c2a71_index_num};
    }

    /* Description: Renders a line containing one or more RML tags. */
    function fun_4f8c2a71_render_tags_i1790129966_v1(var_4f8c2a71_line_str) {
        var var_4f8c2a71_pattern_obj = /\[([^\]]*)\]/g;
        var var_4f8c2a71_match_arr = null;
        var var_4f8c2a71_html_str = "<div class=\"rml_tags\">";
        while ((var_4f8c2a71_match_arr = var_4f8c2a71_pattern_obj.exec(var_4f8c2a71_line_str)) !== null) {
            var_4f8c2a71_html_str += "<span class=\"rml_tag\">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_match_arr[1]) + "</span>";
        }
        return var_4f8c2a71_html_str + "</div>";
    }

    /* Description: Finds the closing delimiter for quote, message, and styled blocks while respecting an optional RML block ID. */
    function fun_4f8c2a71_find_block_end_i1790129967_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_start_num, var_4f8c2a71_end_num, var_4f8c2a71_close_str) {
        var var_4f8c2a71_index_num = var_4f8c2a71_start_num + 1;
        while (var_4f8c2a71_index_num < var_4f8c2a71_end_num) {
            if (var_4f8c2a71_lines_arr[var_4f8c2a71_index_num] === var_4f8c2a71_close_str) {
                return var_4f8c2a71_index_num;
            }
            var_4f8c2a71_index_num += 1;
        }
        return -1;
    }

    /* Description: Parses a range of RML lines, recursively processing styled blocks while preserving literal blocks. */
    function fun_4f8c2a71_parse_lines_i1790129968_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_start_num, var_4f8c2a71_end_num) {
        var var_4f8c2a71_html_str = "";
        var var_4f8c2a71_index_num = var_4f8c2a71_start_num;
        var var_4f8c2a71_line_str = "";
        var var_4f8c2a71_match_arr = null;
        var var_4f8c2a71_close_str = "";
        var var_4f8c2a71_block_end_num = -1;
        var var_4f8c2a71_inner_str = "";
        var var_4f8c2a71_nested_str = "";
        var var_4f8c2a71_list_obj = null;
        var var_4f8c2a71_table_obj = null;
        var var_4f8c2a71_label_str = "";
        var var_4f8c2a71_value_str = "";
        while (var_4f8c2a71_index_num < var_4f8c2a71_end_num) {
            var_4f8c2a71_line_str = var_4f8c2a71_lines_arr[var_4f8c2a71_index_num];
            if (var_4f8c2a71_line_str === "") {
                var_4f8c2a71_index_num += 1;
                continue;
            }
            var_4f8c2a71_match_arr = var_4f8c2a71_line_str.match(/^"(&[a-z0-9]+)?$/);
            if (var_4f8c2a71_match_arr !== null) {
                var_4f8c2a71_close_str = "\"" + (var_4f8c2a71_match_arr[1] || "");
                var_4f8c2a71_block_end_num = fun_4f8c2a71_find_block_end_i1790129967_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_index_num, var_4f8c2a71_end_num, var_4f8c2a71_close_str);
                if (var_4f8c2a71_block_end_num !== -1) {
                    var_4f8c2a71_inner_str = var_4f8c2a71_lines_arr.slice(var_4f8c2a71_index_num + 1, var_4f8c2a71_block_end_num).join("\n");
                    var_4f8c2a71_html_str += "<blockquote class=\"rml_blockquote\"><pre class=\"rml_literal_block\">" + fun_4f8c2a71_escape_html_i1790129952_v1(var_4f8c2a71_inner_str) + "</pre></blockquote>";
                    var_4f8c2a71_index_num = var_4f8c2a71_block_end_num + 1;
                    continue;
                }
            }
            var_4f8c2a71_match_arr = var_4f8c2a71_line_str.match(/^\((&[a-z0-9]+)?$/);
            if (var_4f8c2a71_match_arr !== null) {
                var_4f8c2a71_close_str = ")" + (var_4f8c2a71_match_arr[1] || "");
                var_4f8c2a71_block_end_num = fun_4f8c2a71_find_block_end_i1790129967_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_index_num, var_4f8c2a71_end_num, var_4f8c2a71_close_str);
                if (var_4f8c2a71_block_end_num !== -1) {
                    var_4f8c2a71_inner_str = var_4f8c2a71_lines_arr.slice(var_4f8c2a71_index_num + 1, var_4f8c2a71_block_end_num).join("\n");
                    var_4f8c2a71_html_str += "<div class=\"rml_blockmessage\"><pre class=\"rml_literal_block\">" + fun_4f8c2a71_escape_html_i1790129952_v1(var_4f8c2a71_inner_str) + "</pre></div>";
                    var_4f8c2a71_index_num = var_4f8c2a71_block_end_num + 1;
                    continue;
                }
            }
            var_4f8c2a71_match_arr = var_4f8c2a71_line_str.match(/^\[(&[a-z0-9]+)?$/);
            if (var_4f8c2a71_match_arr !== null) {
                var_4f8c2a71_close_str = "]" + (var_4f8c2a71_match_arr[1] || "");
                var_4f8c2a71_block_end_num = fun_4f8c2a71_find_block_end_i1790129967_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_index_num, var_4f8c2a71_end_num, var_4f8c2a71_close_str);
                if (var_4f8c2a71_block_end_num !== -1) {
                    var_4f8c2a71_nested_str = fun_4f8c2a71_parse_lines_i1790129968_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_index_num + 1, var_4f8c2a71_block_end_num);
                    var_4f8c2a71_html_str += "<div class=\"rml_blockstyled\">" + var_4f8c2a71_nested_str + "</div>";
                    var_4f8c2a71_index_num = var_4f8c2a71_block_end_num + 1;
                    continue;
                }
            }
            if (/^\/\/ /.test(var_4f8c2a71_line_str) === true) {
                var_4f8c2a71_html_str += "<!-- " + fun_4f8c2a71_make_html_comment_safe_i1790129954_v1(var_4f8c2a71_line_str.slice(3)) + " -->";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            if (var_4f8c2a71_line_str === "--") {
                var_4f8c2a71_html_str += "<div class=\"rml_page_break\" role=\"separator\" aria-label=\"Page break\"></div>";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            if (var_4f8c2a71_line_str === "---") {
                var_4f8c2a71_html_str += "<hr class=\"rml_horizontal_rule\">";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            var_4f8c2a71_match_arr = var_4f8c2a71_line_str.match(/^(#{1,6}) (.+)$/);
            if (var_4f8c2a71_match_arr !== null) {
                var_4f8c2a71_html_str += "<h" + var_4f8c2a71_match_arr[1].length + ">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_match_arr[2]) + "</h" + var_4f8c2a71_match_arr[1].length + ">";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            if (/^\|\| .* \|\|$/.test(var_4f8c2a71_line_str) === true) {
                var_4f8c2a71_table_obj = fun_4f8c2a71_render_table_i1790129965_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_index_num, var_4f8c2a71_end_num);
                var_4f8c2a71_html_str += var_4f8c2a71_table_obj.html;
                var_4f8c2a71_index_num = var_4f8c2a71_table_obj.next;
                continue;
            }
            if (/^\| .* \|$/.test(var_4f8c2a71_line_str) === true) {
                var_4f8c2a71_html_str += fun_4f8c2a71_render_flat_list_i1790129964_v1(var_4f8c2a71_line_str);
                var_4f8c2a71_index_num += 1;
                continue;
            }
            if (fun_4f8c2a71_get_list_line_i1790129960_v1(var_4f8c2a71_line_str) !== null) {
                var_4f8c2a71_list_obj = fun_4f8c2a71_render_list_i1790129963_v1(var_4f8c2a71_lines_arr, var_4f8c2a71_index_num, var_4f8c2a71_end_num);
                var_4f8c2a71_html_str += var_4f8c2a71_list_obj.html;
                var_4f8c2a71_index_num = var_4f8c2a71_list_obj.next;
                continue;
            }
            if (/^(?:\[[^\]\n]*\])+$/.test(var_4f8c2a71_line_str) === true) {
                var_4f8c2a71_html_str += fun_4f8c2a71_render_tags_i1790129966_v1(var_4f8c2a71_line_str);
                var_4f8c2a71_index_num += 1;
                continue;
            }
            if (/^\(IMAGE: .+\)$/.test(var_4f8c2a71_line_str) === true) {
                var_4f8c2a71_html_str += "<div class=\"rml_image_block\">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_line_str) + "</div>";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            var_4f8c2a71_match_arr = var_4f8c2a71_line_str.match(/^([^a-z:]+): (.*)$/);
            if (var_4f8c2a71_match_arr !== null) {
                var_4f8c2a71_label_str = var_4f8c2a71_match_arr[1];
                var_4f8c2a71_value_str = var_4f8c2a71_match_arr[2];
                var_4f8c2a71_html_str += "<div class=\"rml_label_value\"><span class=\"rml_label_name\">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_label_str) + ":</span> <span class=\"rml_label_value_text\">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_value_str) + "</span></div>";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            if (var_4f8c2a71_line_str.endsWith(":") === true) {
                var_4f8c2a71_html_str += "<div class=\"rml_item_label\">" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_line_str) + "</div>";
                var_4f8c2a71_index_num += 1;
                continue;
            }
            var_4f8c2a71_html_str += "<p>" + fun_4f8c2a71_parse_inline_i1790129959_v1(var_4f8c2a71_line_str) + "</p>";
            var_4f8c2a71_index_num += 1;
        }
        return var_4f8c2a71_html_str;
    }

    /* Description: Normalizes newlines and converts a complete RML v5 document to an HTML fragment. */
    function fun_4f8c2a71_parse_document_i1790129969_v1(var_4f8c2a71_rml_str) {
        var var_4f8c2a71_normalized_str = String(var_4f8c2a71_rml_str).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
        var var_4f8c2a71_lines_arr = var_4f8c2a71_normalized_str.split("\n");
        return "<div class=\"rml_document\">" + fun_4f8c2a71_parse_lines_i1790129968_v1(var_4f8c2a71_lines_arr, 0, var_4f8c2a71_lines_arr.length) + "</div>";
    }

    var_4f8c2a71_global_obj.RitcheyRmlParser = {
        parse: fun_4f8c2a71_parse_document_i1790129969_v1,
        parseInline: fun_4f8c2a71_parse_inline_i1790129959_v1
    };
}(window));
