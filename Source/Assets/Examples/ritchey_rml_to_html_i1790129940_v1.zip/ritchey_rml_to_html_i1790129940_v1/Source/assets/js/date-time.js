/* Description: Displays the current local date and time in several copyable formats. */
(function () {
    "use strict";

    function fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_value_int) {
        return String(var_4e2c71b0_value_int).padStart(2, "0");
    }

    function fun_4e2c71b0_set_text_i1790130045_v1(var_4e2c71b0_id_str, var_4e2c71b0_value_str) {
        var var_4e2c71b0_target_obj = document.getElementById(var_4e2c71b0_id_str);
        if (var_4e2c71b0_target_obj !== null) { var_4e2c71b0_target_obj.textContent = var_4e2c71b0_value_str; }
    }

    function fun_4e2c71b0_update_i1790130046_v1() {
        var var_4e2c71b0_now_obj = new Date();
        var var_4e2c71b0_months_arr = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var var_4e2c71b0_year_int = var_4e2c71b0_now_obj.getFullYear();
        var var_4e2c71b0_month_int = var_4e2c71b0_now_obj.getMonth() + 1;
        var var_4e2c71b0_day_int = var_4e2c71b0_now_obj.getDate();
        var var_4e2c71b0_hour24_int = var_4e2c71b0_now_obj.getHours();
        var var_4e2c71b0_minute_int = var_4e2c71b0_now_obj.getMinutes();
        var var_4e2c71b0_second_int = var_4e2c71b0_now_obj.getSeconds();
        var var_4e2c71b0_suffix_str = var_4e2c71b0_hour24_int >= 12 ? "PM" : "AM";
        var var_4e2c71b0_hour12_int = var_4e2c71b0_hour24_int % 12;
        if (var_4e2c71b0_hour12_int === 0) { var_4e2c71b0_hour12_int = 12; }
        fun_4e2c71b0_set_text_i1790130045_v1("date_time_long", var_4e2c71b0_months_arr[var_4e2c71b0_month_int - 1] + " " + var_4e2c71b0_day_int + ", " + var_4e2c71b0_year_int + " " + var_4e2c71b0_hour12_int + ":" + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_minute_int) + ":" + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_second_int) + " " + var_4e2c71b0_suffix_str);
        fun_4e2c71b0_set_text_i1790130045_v1("date_time_mdy", fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_month_int) + "-" + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_day_int) + "-" + var_4e2c71b0_year_int + " " + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_hour24_int) + ":" + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_minute_int));
        fun_4e2c71b0_set_text_i1790130045_v1("date_time_ymd", var_4e2c71b0_year_int + "-" + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_month_int) + "-" + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_day_int) + " " + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_hour24_int) + ":" + fun_4e2c71b0_pad_i1790130044_v1(var_4e2c71b0_minute_int));
        fun_4e2c71b0_set_text_i1790130045_v1("date_time_ritchey", "Y" + var_4e2c71b0_year_int + "M" + var_4e2c71b0_month_int + "D" + var_4e2c71b0_day_int + " H" + var_4e2c71b0_hour12_int + "M" + var_4e2c71b0_minute_int + "S" + var_4e2c71b0_second_int + var_4e2c71b0_suffix_str);
        fun_4e2c71b0_set_text_i1790130045_v1("date_time_unix", String(Math.floor(var_4e2c71b0_now_obj.getTime() / 1000)));
    }

    function fun_4e2c71b0_copy_i1790130047_v1(var_4e2c71b0_event_obj) {
        var var_4e2c71b0_button_obj = var_4e2c71b0_event_obj.currentTarget;
        var var_4e2c71b0_target_obj = document.getElementById(var_4e2c71b0_button_obj.getAttribute("data-copy-target"));
        var var_4e2c71b0_status_obj = document.getElementById("date_time_status");
        var var_4e2c71b0_label_str = var_4e2c71b0_button_obj.getAttribute("data-copy-label") || "Date-time";
        var var_4e2c71b0_value_str = var_4e2c71b0_target_obj === null ? "" : var_4e2c71b0_target_obj.textContent;
        if (var_4e2c71b0_value_str === "") { return; }
        window.RitcheyClipboard.copyText(var_4e2c71b0_value_str, function () {
            var_4e2c71b0_status_obj.textContent = var_4e2c71b0_label_str + " copied to the clipboard.";
            var_4e2c71b0_status_obj.setAttribute("data-state", "success");
        }, function () {
            var_4e2c71b0_status_obj.textContent = "Copy was blocked by the browser.";
            var_4e2c71b0_status_obj.setAttribute("data-state", "error");
        });
    }

    function fun_4e2c71b0_initialize_i1790130048_v1() {
        var var_4e2c71b0_buttons_obj = document.querySelectorAll(".date_time_copy_button");
        var var_4e2c71b0_index_int = 0;
        fun_4e2c71b0_update_i1790130046_v1();
        window.setInterval(fun_4e2c71b0_update_i1790130046_v1, 1000);
        while (var_4e2c71b0_index_int < var_4e2c71b0_buttons_obj.length) {
            var_4e2c71b0_buttons_obj[var_4e2c71b0_index_int].addEventListener("click", fun_4e2c71b0_copy_i1790130047_v1);
            var_4e2c71b0_index_int += 1;
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", fun_4e2c71b0_initialize_i1790130048_v1);
    } else {
        fun_4e2c71b0_initialize_i1790130048_v1();
    }
}());
