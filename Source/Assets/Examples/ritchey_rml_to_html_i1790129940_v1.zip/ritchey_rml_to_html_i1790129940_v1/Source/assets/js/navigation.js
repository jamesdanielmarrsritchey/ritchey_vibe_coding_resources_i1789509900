/* Description: Shows a Return control on the Navigation page when a safe same-origin referring page is known. */
(function () {
    "use strict";

    function fun_f1c57d30_set_return_state_i1790129945_v4(var_f1c57d30_link_obj, var_f1c57d30_header_obj, var_f1c57d30_visible_boo) {
        if (var_f1c57d30_visible_boo === true) {
            var_f1c57d30_link_obj.hidden = false;
            var_f1c57d30_header_obj.setAttribute("data-return-visible", "true");
        } else {
            var_f1c57d30_link_obj.hidden = true;
            var_f1c57d30_header_obj.setAttribute("data-return-visible", "false");
        }
    }

    function fun_f1c57d30_initialize_return_link_i1790129946_v4() {
        var var_f1c57d30_link_obj = document.getElementById("navigation_return_button");
        var var_f1c57d30_header_obj = document.getElementById("header_section_2");
        var var_f1c57d30_referrer_str = document.referrer || "";
        var var_f1c57d30_referrer_obj = null;
        if (var_f1c57d30_link_obj === null || var_f1c57d30_header_obj === null || var_f1c57d30_referrer_str === "") {
            if (var_f1c57d30_link_obj !== null && var_f1c57d30_header_obj !== null) {
                fun_f1c57d30_set_return_state_i1790129945_v4(var_f1c57d30_link_obj, var_f1c57d30_header_obj, false);
            }
            return;
        }
        try {
            var_f1c57d30_referrer_obj = new URL(var_f1c57d30_referrer_str, window.location.href);
        } catch (var_f1c57d30_error_obj) {
            fun_f1c57d30_set_return_state_i1790129945_v4(var_f1c57d30_link_obj, var_f1c57d30_header_obj, false);
            return;
        }
        if (var_f1c57d30_referrer_obj.origin !== window.location.origin || var_f1c57d30_referrer_obj.href === window.location.href) {
            fun_f1c57d30_set_return_state_i1790129945_v4(var_f1c57d30_link_obj, var_f1c57d30_header_obj, false);
            return;
        }
        var_f1c57d30_link_obj.href = var_f1c57d30_referrer_obj.href;
        fun_f1c57d30_set_return_state_i1790129945_v4(var_f1c57d30_link_obj, var_f1c57d30_header_obj, true);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", fun_f1c57d30_initialize_return_link_i1790129946_v4);
    } else {
        fun_f1c57d30_initialize_return_link_i1790129946_v4();
    }
}());
