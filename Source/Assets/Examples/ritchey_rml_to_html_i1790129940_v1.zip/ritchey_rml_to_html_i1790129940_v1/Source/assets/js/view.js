/* Description: Reconstructs RML from the content query parameter, renders it, and offers publication downloads. */
(function () {
    "use strict";

    var var_2c74ad6e_rml_str = "";
    var var_2c74ad6e_encoded_str = "";

    function fun_2c74ad6e_show_view_error_i1790129977_v3(var_2c74ad6e_message_str) {
        var var_2c74ad6e_content_obj = document.getElementById("published_content");
        var var_2c74ad6e_status_obj = document.getElementById("view_status");
        var var_2c74ad6e_download_obj = document.getElementById("download_area");
        var_2c74ad6e_content_obj.innerHTML = "";
        var_2c74ad6e_status_obj.textContent = var_2c74ad6e_message_str;
        var_2c74ad6e_status_obj.setAttribute("data-state", "error");
        if (var_2c74ad6e_download_obj !== null) { var_2c74ad6e_download_obj.hidden = true; }
    }

    function fun_2c74ad6e_update_document_title_i1790129978_v2() {
        var var_2c74ad6e_heading_obj = document.querySelector("#published_content h1, #published_content h2, #published_content h3, #published_content h4, #published_content h5, #published_content h6");
        if (var_2c74ad6e_heading_obj !== null && var_2c74ad6e_heading_obj.textContent.trim() !== "") {
            document.title = var_2c74ad6e_heading_obj.textContent.trim() + " | Ritchey&AI RML To HTML";
        }
    }

    function fun_2c74ad6e_download_text_i1790130001_v1(var_2c74ad6e_text_str, var_2c74ad6e_filename_str) {
        var var_2c74ad6e_blob_obj = new Blob([var_2c74ad6e_text_str], {type: "text/plain;charset=utf-8"});
        var var_2c74ad6e_url_str = URL.createObjectURL(var_2c74ad6e_blob_obj);
        var var_2c74ad6e_anchor_obj = document.createElement("a");
        var_2c74ad6e_anchor_obj.href = var_2c74ad6e_url_str;
        var_2c74ad6e_anchor_obj.download = var_2c74ad6e_filename_str;
        document.body.appendChild(var_2c74ad6e_anchor_obj);
        var_2c74ad6e_anchor_obj.click();
        document.body.removeChild(var_2c74ad6e_anchor_obj);
        URL.revokeObjectURL(var_2c74ad6e_url_str);
    }

    function fun_2c74ad6e_download_rml_i1790130002_v1() {
        fun_2c74ad6e_download_text_i1790130001_v1(var_2c74ad6e_rml_str, "publication-rml.txt");
    }

    function fun_2c74ad6e_download_compressed_i1790130003_v1() {
        fun_2c74ad6e_download_text_i1790130001_v1(var_2c74ad6e_encoded_str, "publication-compressed.txt");
    }

    function fun_2c74ad6e_enable_downloads_i1790130004_v1() {
        var var_2c74ad6e_area_obj = document.getElementById("download_area");
        var var_2c74ad6e_rml_button_obj = document.getElementById("download_rml");
        var var_2c74ad6e_compressed_button_obj = document.getElementById("download_compressed");
        if (var_2c74ad6e_area_obj !== null) { var_2c74ad6e_area_obj.hidden = false; }
        if (var_2c74ad6e_rml_button_obj !== null) { var_2c74ad6e_rml_button_obj.addEventListener("click", fun_2c74ad6e_download_rml_i1790130002_v1); }
        if (var_2c74ad6e_compressed_button_obj !== null) { var_2c74ad6e_compressed_button_obj.addEventListener("click", fun_2c74ad6e_download_compressed_i1790130003_v1); }
    }

    function fun_2c74ad6e_submit_manual_content_i1790129980_v2(var_2c74ad6e_event_obj) {
        var var_2c74ad6e_input_obj = document.getElementById("content_input");
        var var_2c74ad6e_status_obj = document.getElementById("view_status");
        var var_2c74ad6e_value_str = "";
        var var_2c74ad6e_url_obj = null;
        var_2c74ad6e_event_obj.preventDefault();
        if (var_2c74ad6e_input_obj !== null) { var_2c74ad6e_value_str = var_2c74ad6e_input_obj.value.trim(); }
        if (var_2c74ad6e_value_str === "") {
            var_2c74ad6e_status_obj.textContent = "Enter encoded content.";
            var_2c74ad6e_status_obj.setAttribute("data-state", "error");
            return;
        }
        var_2c74ad6e_url_obj = new URL(window.location.href);
        var_2c74ad6e_url_obj.search = "";
        var_2c74ad6e_url_obj.searchParams.set("content", var_2c74ad6e_value_str);
        window.location.href = var_2c74ad6e_url_obj.toString();
    }

    function fun_2c74ad6e_show_manual_content_form_i1790129981_v2() {
        var var_2c74ad6e_panel_obj = document.getElementById("content_entry_panel");
        var var_2c74ad6e_form_obj = document.getElementById("content_entry_form");
        var var_2c74ad6e_status_obj = document.getElementById("view_status");
        if (var_2c74ad6e_panel_obj !== null) { var_2c74ad6e_panel_obj.hidden = false; }
        if (var_2c74ad6e_status_obj !== null) {
            var_2c74ad6e_status_obj.textContent = "";
            var_2c74ad6e_status_obj.setAttribute("data-state", "");
        }
        if (var_2c74ad6e_form_obj !== null) { var_2c74ad6e_form_obj.addEventListener("submit", fun_2c74ad6e_submit_manual_content_i1790129980_v2); }
    }

    function fun_2c74ad6e_initialize_view_page_i1790129979_v3() {
        var var_2c74ad6e_parameters_obj = new URLSearchParams(window.location.search);
        var_2c74ad6e_encoded_str = var_2c74ad6e_parameters_obj.get("content") || "";
        var var_2c74ad6e_content_obj = document.getElementById("published_content");
        var var_2c74ad6e_status_obj = document.getElementById("view_status");
        if (var_2c74ad6e_encoded_str === "") {
            fun_2c74ad6e_show_manual_content_form_i1790129981_v2();
            return;
        }
        var_2c74ad6e_status_obj.textContent = "Opening published RML...";
        window.RitcheyContentCodec.decode(var_2c74ad6e_encoded_str).then(function (var_2c74ad6e_decoded_str) {
            var_2c74ad6e_rml_str = var_2c74ad6e_decoded_str;
            var_2c74ad6e_content_obj.innerHTML = window.RitcheyRmlParser.parse(var_2c74ad6e_rml_str);
            var_2c74ad6e_status_obj.textContent = "";
            var_2c74ad6e_status_obj.setAttribute("data-state", "");
            fun_2c74ad6e_update_document_title_i1790129978_v2();
            fun_2c74ad6e_enable_downloads_i1790130004_v1();
        }).catch(function (var_2c74ad6e_error_obj) {
            fun_2c74ad6e_show_view_error_i1790129977_v3(var_2c74ad6e_error_obj.message || "The published RML could not be opened.");
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", fun_2c74ad6e_initialize_view_page_i1790129979_v3);
    } else {
        fun_2c74ad6e_initialize_view_page_i1790129979_v3();
    }
}());
