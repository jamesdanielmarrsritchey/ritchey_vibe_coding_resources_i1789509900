/* Description: Provides the shared Day/Night theme toggle and persists the selected theme. */
(function () {
    "use strict";

    function fun_6b8b12f4_apply_theme_i1790129941_v2(var_6b8b12f4_theme_str) {
        var var_6b8b12f4_buttons_arr = document.querySelectorAll("[data-theme-toggle]");
        var var_6b8b12f4_index_num = 0;
        var var_6b8b12f4_button_obj = null;
        var var_6b8b12f4_target_theme_str = var_6b8b12f4_theme_str === "night" ? "day" : "night";
        document.documentElement.setAttribute("data-theme", var_6b8b12f4_theme_str);
        while (var_6b8b12f4_index_num < var_6b8b12f4_buttons_arr.length) {
            var_6b8b12f4_button_obj = var_6b8b12f4_buttons_arr[var_6b8b12f4_index_num];
            var_6b8b12f4_button_obj.setAttribute("data-target-theme", var_6b8b12f4_target_theme_str);
            var_6b8b12f4_button_obj.setAttribute("aria-label", "Switch to " + var_6b8b12f4_target_theme_str + " theme");
            var_6b8b12f4_button_obj.setAttribute("title", "Switch to " + var_6b8b12f4_target_theme_str + " theme");
            var_6b8b12f4_button_obj.setAttribute("aria-pressed", var_6b8b12f4_theme_str === "night" ? "true" : "false");
            var_6b8b12f4_index_num += 1;
        }
    }

    function fun_6b8b12f4_get_initial_theme_i1790129942_v2() {
        var var_6b8b12f4_saved_theme_str = "";
        try { var_6b8b12f4_saved_theme_str = window.localStorage.getItem("ritchey_rml_to_html_theme") || ""; }
        catch (var_6b8b12f4_error_obj) { var_6b8b12f4_saved_theme_str = ""; }
        if (var_6b8b12f4_saved_theme_str === "day" || var_6b8b12f4_saved_theme_str === "night") { return var_6b8b12f4_saved_theme_str; }
        if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches === true) { return "night"; }
        return "day";
    }

    function fun_6b8b12f4_toggle_theme_i1790129943_v2() {
        var var_6b8b12f4_current_theme_str = document.documentElement.getAttribute("data-theme") || "day";
        var var_6b8b12f4_next_theme_str = var_6b8b12f4_current_theme_str === "night" ? "day" : "night";
        fun_6b8b12f4_apply_theme_i1790129941_v2(var_6b8b12f4_next_theme_str);
        try { window.localStorage.setItem("ritchey_rml_to_html_theme", var_6b8b12f4_next_theme_str); }
        catch (var_6b8b12f4_error_obj) { return; }
    }

    function fun_6b8b12f4_initialize_theme_i1790129944_v2() {
        var var_6b8b12f4_buttons_arr = document.querySelectorAll("[data-theme-toggle]");
        var var_6b8b12f4_index_num = 0;
        fun_6b8b12f4_apply_theme_i1790129941_v2(fun_6b8b12f4_get_initial_theme_i1790129942_v2());
        while (var_6b8b12f4_index_num < var_6b8b12f4_buttons_arr.length) {
            var_6b8b12f4_buttons_arr[var_6b8b12f4_index_num].addEventListener("click", fun_6b8b12f4_toggle_theme_i1790129943_v2);
            var_6b8b12f4_index_num += 1;
        }
    }

    if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", fun_6b8b12f4_initialize_theme_i1790129944_v2); }
    else { fun_6b8b12f4_initialize_theme_i1790129944_v2(); }
}());
