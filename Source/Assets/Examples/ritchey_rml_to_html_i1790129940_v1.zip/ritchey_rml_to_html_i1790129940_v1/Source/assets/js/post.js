/* Description: Connects the RML editor to live preview, URL publication, clipboard copying, and navigation. */
(function () {
    "use strict";

    var var_8d43b711_rml_input_obj = null;
    var var_8d43b711_preview_obj = null;
    var var_8d43b711_submit_obj = null;
    var var_8d43b711_url_obj = null;
    var var_8d43b711_url_full_obj = null;
    var var_8d43b711_copy_obj = null;
    var var_8d43b711_copy_full_obj = null;
    var var_8d43b711_go_obj = null;
    var var_8d43b711_status_obj = null;

    /* Description: Updates the live HTML preview from the exact RML currently in the input area. */
    function fun_8d43b711_update_preview_i1790129970_v1() {
        var_8d43b711_preview_obj.innerHTML = window.RitcheyRmlParser.parse(var_8d43b711_rml_input_obj.value);
    }

    /* Description: Displays a status message with an optional success or error state. */
    function fun_8d43b711_set_status_i1790129971_v1(var_8d43b711_message_str, var_8d43b711_state_str) {
        var_8d43b711_status_obj.textContent = var_8d43b711_message_str;
        var_8d43b711_status_obj.setAttribute("data-state", var_8d43b711_state_str || "");
    }

    /* Description: Converts the current RML into the shortest supported URL-safe payload and builds relative and full view-page URLs. */
    function fun_8d43b711_generate_url_i1790129972_v1() {
        var var_8d43b711_content_str = var_8d43b711_rml_input_obj.value;
        var_8d43b711_submit_obj.disabled = true;
        fun_8d43b711_set_status_i1790129971_v1("Creating the publication URLs...", "");

        window.RitcheyContentCodec.encode(var_8d43b711_content_str).then(function (var_8d43b711_encoded_str) {
            var var_8d43b711_relative_str = "view.html?content=" + encodeURIComponent(var_8d43b711_encoded_str);
            var var_8d43b711_full_str = new URL(var_8d43b711_relative_str, window.location.href).href;

            var_8d43b711_url_obj.value = var_8d43b711_relative_str;
            var_8d43b711_url_full_obj.value = var_8d43b711_full_str;
            var_8d43b711_copy_obj.disabled = false;
            var_8d43b711_copy_full_obj.disabled = false;
            var_8d43b711_go_obj.disabled = false;
            fun_8d43b711_set_status_i1790129971_v1("Publication URLs created.", "success");
        }).catch(function (var_8d43b711_error_obj) {
            var_8d43b711_url_obj.value = "";
            var_8d43b711_url_full_obj.value = "";
            var_8d43b711_copy_obj.disabled = true;
            var_8d43b711_copy_full_obj.disabled = true;
            var_8d43b711_go_obj.disabled = true;
            fun_8d43b711_set_status_i1790129971_v1(var_8d43b711_error_obj.message || "The publication URLs could not be created.", "error");
        }).finally(function () {
            var_8d43b711_submit_obj.disabled = false;
        });
    }

    /* Description: Copies a generated URL, using the modern Clipboard API first and a local fallback when needed. */
    function fun_8d43b711_copy_value_i1790129973_v1(var_8d43b711_input_obj, var_8d43b711_label_str) {
        var var_8d43b711_value_str = var_8d43b711_input_obj.value;

        if (var_8d43b711_value_str === "") {
            return;
        }

        if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
            navigator.clipboard.writeText(var_8d43b711_value_str).then(function () {
                fun_8d43b711_set_status_i1790129971_v1(var_8d43b711_label_str + " copied to the clipboard.", "success");
            }).catch(function () {
                fun_8d43b711_copy_value_fallback_i1790129974_v1(var_8d43b711_input_obj, var_8d43b711_label_str);
            });
            return;
        }

        fun_8d43b711_copy_value_fallback_i1790129974_v1(var_8d43b711_input_obj, var_8d43b711_label_str);
    }

    /* Description: Copies a generated URL through the selected input when Clipboard API access is unavailable. */
    function fun_8d43b711_copy_value_fallback_i1790129974_v1(var_8d43b711_input_obj, var_8d43b711_label_str) {
        var var_8d43b711_success_boo = false;

        var_8d43b711_input_obj.focus();
        var_8d43b711_input_obj.select();

        try {
            var_8d43b711_success_boo = document.execCommand("copy") === true;
        } catch (var_8d43b711_error_obj) {
            var_8d43b711_success_boo = false;
        }

        fun_8d43b711_set_status_i1790129971_v1(
            var_8d43b711_success_boo === true ?
                var_8d43b711_label_str + " copied to the clipboard." :
                "Copy was blocked. The URL is selected so it can be copied manually.",
            var_8d43b711_success_boo === true ? "success" : "error"
        );
    }

    /* Description: Opens the generated full publication URL in the current browser tab. */
    function fun_8d43b711_go_to_url_i1790129975_v1() {
        if (var_8d43b711_url_full_obj.value !== "") {
            window.location.href = var_8d43b711_url_full_obj.value;
        }
    }

    /* Description: Locates page controls and attaches all editor event handlers. */
    function fun_8d43b711_initialize_post_page_i1790129976_v1() {
        var_8d43b711_rml_input_obj = document.getElementById("rml_input");
        var_8d43b711_preview_obj = document.getElementById("live_preview");
        var_8d43b711_submit_obj = document.getElementById("submit_rml");
        var_8d43b711_url_obj = document.getElementById("generated_url");
        var_8d43b711_url_full_obj = document.getElementById("generated_url_full");
        var_8d43b711_copy_obj = document.getElementById("copy_url");
        var_8d43b711_copy_full_obj = document.getElementById("copy_url_full");
        var_8d43b711_go_obj = document.getElementById("go_to_url");
        var_8d43b711_status_obj = document.getElementById("post_status");

        var_8d43b711_rml_input_obj.addEventListener("input", fun_8d43b711_update_preview_i1790129970_v1);
        var_8d43b711_submit_obj.addEventListener("click", fun_8d43b711_generate_url_i1790129972_v1);
        var_8d43b711_copy_obj.addEventListener("click", function () {
            fun_8d43b711_copy_value_i1790129973_v1(var_8d43b711_url_obj, "Item URL");
        });
        var_8d43b711_copy_full_obj.addEventListener("click", function () {
            fun_8d43b711_copy_value_i1790129973_v1(var_8d43b711_url_full_obj, "Full item URL");
        });
        var_8d43b711_go_obj.addEventListener("click", fun_8d43b711_go_to_url_i1790129975_v1);

        fun_8d43b711_update_preview_i1790129970_v1();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", fun_8d43b711_initialize_post_page_i1790129976_v1);
    } else {
        fun_8d43b711_initialize_post_page_i1790129976_v1();
    }
}());
