/* Description: Encodes RML into URL-safe content strings and decodes those strings without third-party dependencies. */
(function (var_31f0dca8_global_obj) {
    "use strict";

    /* Description: Converts bytes to Base64URL without using a large function-argument spread. */
    function fun_31f0dca8_bytes_to_base64url_i1790129946_v1(var_31f0dca8_bytes_arr) {
        var var_31f0dca8_binary_str = "";
        var var_31f0dca8_index_num = 0;
        var var_31f0dca8_end_num = 0;
        var var_31f0dca8_chunk_num = 0x8000;
        while (var_31f0dca8_index_num < var_31f0dca8_bytes_arr.length) {
            var_31f0dca8_end_num = Math.min(var_31f0dca8_index_num + var_31f0dca8_chunk_num, var_31f0dca8_bytes_arr.length);
            while (var_31f0dca8_index_num < var_31f0dca8_end_num) {
                var_31f0dca8_binary_str += String.fromCharCode(var_31f0dca8_bytes_arr[var_31f0dca8_index_num]);
                var_31f0dca8_index_num += 1;
            }
        }
        return btoa(var_31f0dca8_binary_str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
    }

    /* Description: Converts Base64URL back to a byte array. */
    function fun_31f0dca8_base64url_to_bytes_i1790129947_v1(var_31f0dca8_base64url_str) {
        var var_31f0dca8_base64_str = var_31f0dca8_base64url_str.replace(/-/g, "+").replace(/_/g, "/");
        var var_31f0dca8_binary_str = "";
        var var_31f0dca8_bytes_arr = null;
        var var_31f0dca8_index_num = 0;
        while (var_31f0dca8_base64_str.length % 4 !== 0) {
            var_31f0dca8_base64_str += "=";
        }
        var_31f0dca8_binary_str = atob(var_31f0dca8_base64_str);
        var_31f0dca8_bytes_arr = new Uint8Array(var_31f0dca8_binary_str.length);
        while (var_31f0dca8_index_num < var_31f0dca8_binary_str.length) {
            var_31f0dca8_bytes_arr[var_31f0dca8_index_num] = var_31f0dca8_binary_str.charCodeAt(var_31f0dca8_index_num);
            var_31f0dca8_index_num += 1;
        }
        return var_31f0dca8_bytes_arr;
    }

    /* Description: Compresses UTF-8 bytes through the browser-native DEFLATE CompressionStream. */
    function fun_31f0dca8_deflate_bytes_i1790129948_v1(var_31f0dca8_bytes_arr) {
        var var_31f0dca8_stream_obj = new Blob([var_31f0dca8_bytes_arr]).stream().pipeThrough(new CompressionStream("deflate"));
        return new Response(var_31f0dca8_stream_obj).arrayBuffer().then(function (var_31f0dca8_buffer_obj) {
            return new Uint8Array(var_31f0dca8_buffer_obj);
        });
    }

    /* Description: Decompresses DEFLATE bytes through the browser-native DecompressionStream. */
    function fun_31f0dca8_inflate_bytes_i1790129949_v1(var_31f0dca8_bytes_arr) {
        var var_31f0dca8_stream_obj = new Blob([var_31f0dca8_bytes_arr]).stream().pipeThrough(new DecompressionStream("deflate"));
        return new Response(var_31f0dca8_stream_obj).arrayBuffer().then(function (var_31f0dca8_buffer_obj) {
            return new Uint8Array(var_31f0dca8_buffer_obj);
        });
    }

    /* Description: Encodes text using plain Base64URL and, when available, DEFLATE Base64URL, selecting whichever result is shorter. */
    function fun_31f0dca8_encode_content_i1790129950_v1(var_31f0dca8_content_str) {
        var var_31f0dca8_bytes_arr = new TextEncoder().encode(var_31f0dca8_content_str);
        var var_31f0dca8_plain_str = "p." + fun_31f0dca8_bytes_to_base64url_i1790129946_v1(var_31f0dca8_bytes_arr);
        if (typeof CompressionStream === "undefined") {
            return Promise.resolve(var_31f0dca8_plain_str);
        }
        return fun_31f0dca8_deflate_bytes_i1790129948_v1(var_31f0dca8_bytes_arr).then(function (var_31f0dca8_compressed_arr) {
            var var_31f0dca8_compressed_str = "c." + fun_31f0dca8_bytes_to_base64url_i1790129946_v1(var_31f0dca8_compressed_arr);
            if (var_31f0dca8_compressed_str.length < var_31f0dca8_plain_str.length) {
                return var_31f0dca8_compressed_str;
            }
            return var_31f0dca8_plain_str;
        }).catch(function () {
            return var_31f0dca8_plain_str;
        });
    }

    /* Description: Decodes a published content string, using native DEFLATE decompression only for values carrying the c. prefix. */
    function fun_31f0dca8_decode_content_i1790129951_v1(var_31f0dca8_encoded_str) {
        var var_31f0dca8_mode_str = "";
        var var_31f0dca8_payload_str = "";
        var var_31f0dca8_bytes_arr = null;
        if (typeof var_31f0dca8_encoded_str !== "string" || var_31f0dca8_encoded_str.length < 3 || var_31f0dca8_encoded_str.charAt(1) !== ".") {
            return Promise.reject(new Error("The content parameter does not use a recognized encoding format."));
        }
        var_31f0dca8_mode_str = var_31f0dca8_encoded_str.charAt(0);
        var_31f0dca8_payload_str = var_31f0dca8_encoded_str.slice(2);
        try {
            var_31f0dca8_bytes_arr = fun_31f0dca8_base64url_to_bytes_i1790129947_v1(var_31f0dca8_payload_str);
        } catch (var_31f0dca8_error_obj) {
            return Promise.reject(new Error("The content parameter contains invalid Base64URL data."));
        }
        if (var_31f0dca8_mode_str === "p") {
            try {
                return Promise.resolve(new TextDecoder("utf-8", {fatal: true}).decode(var_31f0dca8_bytes_arr));
            } catch (var_31f0dca8_error_obj) {
                return Promise.reject(new Error("The content parameter does not contain valid UTF-8 text."));
            }
        }
        if (var_31f0dca8_mode_str === "c") {
            if (typeof DecompressionStream === "undefined") {
                return Promise.reject(new Error("This browser cannot decompress this published URL because DecompressionStream is unavailable."));
            }
            return fun_31f0dca8_inflate_bytes_i1790129949_v1(var_31f0dca8_bytes_arr).then(function (var_31f0dca8_decompressed_arr) {
                return new TextDecoder("utf-8", {fatal: true}).decode(var_31f0dca8_decompressed_arr);
            }).catch(function () {
                throw new Error("The compressed content parameter is invalid or damaged.");
            });
        }
        return Promise.reject(new Error("The content parameter uses an unsupported encoding mode."));
    }

    var_31f0dca8_global_obj.RitcheyContentCodec = {
        encode: fun_31f0dca8_encode_content_i1790129950_v1,
        decode: fun_31f0dca8_decode_content_i1790129951_v1
    };
}(window));
