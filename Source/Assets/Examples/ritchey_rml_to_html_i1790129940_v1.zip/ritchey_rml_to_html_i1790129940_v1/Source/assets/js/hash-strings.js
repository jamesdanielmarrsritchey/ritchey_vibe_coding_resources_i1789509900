/* Description: Hash Strings widget implementations for SHA3, Web Crypto SHA algorithms, MD5, and CRC32. */
(function () {
    "use strict";

    var var_7bd550b7_mask64_bigint = (1n << 64n) - 1n;
    var var_7bd550b7_keccak_rotation_arr = [
        0, 1, 62, 28, 27,
        36, 44, 6, 55, 20,
        3, 10, 43, 25, 39,
        41, 45, 15, 21, 8,
        18, 2, 61, 56, 14
    ];
    var var_7bd550b7_keccak_round_arr = [
        0x0000000000000001n, 0x0000000000008082n, 0x800000000000808an, 0x8000000080008000n,
        0x000000000000808bn, 0x0000000080000001n, 0x8000000080008081n, 0x8000000000008009n,
        0x000000000000008an, 0x0000000000000088n, 0x0000000080008009n, 0x000000008000000an,
        0x000000008000808bn, 0x800000000000008bn, 0x8000000000008089n, 0x8000000000008003n,
        0x8000000000008002n, 0x8000000000000080n, 0x000000000000800an, 0x800000008000000an,
        0x8000000080008081n, 0x8000000000008080n, 0x0000000080000001n, 0x8000000080008008n
    ];

    function fun_7bd550b7_rotate_left_64_i1790129990_v1(var_7bd550b7_value_bigint, var_7bd550b7_shift_int) {
        if (var_7bd550b7_shift_int === 0) { return var_7bd550b7_value_bigint & var_7bd550b7_mask64_bigint; }
        return ((var_7bd550b7_value_bigint << BigInt(var_7bd550b7_shift_int)) |
            (var_7bd550b7_value_bigint >> BigInt(64 - var_7bd550b7_shift_int))) & var_7bd550b7_mask64_bigint;
    }

    function fun_7bd550b7_keccak_f_i1790129991_v1(var_7bd550b7_state_arr) {
        var var_7bd550b7_round_int = 0;
        var var_7bd550b7_x_int = 0;
        var var_7bd550b7_y_int = 0;
        var var_7bd550b7_c_arr = new Array(5);
        var var_7bd550b7_d_arr = new Array(5);
        var var_7bd550b7_b_arr = new Array(25);
        for (var_7bd550b7_round_int = 0; var_7bd550b7_round_int < 24; var_7bd550b7_round_int += 1) {
            for (var_7bd550b7_x_int = 0; var_7bd550b7_x_int < 5; var_7bd550b7_x_int += 1) {
                var_7bd550b7_c_arr[var_7bd550b7_x_int] = var_7bd550b7_state_arr[var_7bd550b7_x_int] ^
                    var_7bd550b7_state_arr[var_7bd550b7_x_int + 5] ^ var_7bd550b7_state_arr[var_7bd550b7_x_int + 10] ^
                    var_7bd550b7_state_arr[var_7bd550b7_x_int + 15] ^ var_7bd550b7_state_arr[var_7bd550b7_x_int + 20];
            }
            for (var_7bd550b7_x_int = 0; var_7bd550b7_x_int < 5; var_7bd550b7_x_int += 1) {
                var_7bd550b7_d_arr[var_7bd550b7_x_int] = var_7bd550b7_c_arr[(var_7bd550b7_x_int + 4) % 5] ^
                    fun_7bd550b7_rotate_left_64_i1790129990_v1(var_7bd550b7_c_arr[(var_7bd550b7_x_int + 1) % 5], 1);
            }
            for (var_7bd550b7_y_int = 0; var_7bd550b7_y_int < 5; var_7bd550b7_y_int += 1) {
                for (var_7bd550b7_x_int = 0; var_7bd550b7_x_int < 5; var_7bd550b7_x_int += 1) {
                    var_7bd550b7_state_arr[var_7bd550b7_x_int + (5 * var_7bd550b7_y_int)] =
                        (var_7bd550b7_state_arr[var_7bd550b7_x_int + (5 * var_7bd550b7_y_int)] ^ var_7bd550b7_d_arr[var_7bd550b7_x_int]) & var_7bd550b7_mask64_bigint;
                }
            }
            for (var_7bd550b7_y_int = 0; var_7bd550b7_y_int < 5; var_7bd550b7_y_int += 1) {
                for (var_7bd550b7_x_int = 0; var_7bd550b7_x_int < 5; var_7bd550b7_x_int += 1) {
                    var var_7bd550b7_source_int = var_7bd550b7_x_int + (5 * var_7bd550b7_y_int);
                    var var_7bd550b7_target_x_int = var_7bd550b7_y_int;
                    var var_7bd550b7_target_y_int = ((2 * var_7bd550b7_x_int) + (3 * var_7bd550b7_y_int)) % 5;
                    var_7bd550b7_b_arr[var_7bd550b7_target_x_int + (5 * var_7bd550b7_target_y_int)] =
                        fun_7bd550b7_rotate_left_64_i1790129990_v1(var_7bd550b7_state_arr[var_7bd550b7_source_int], var_7bd550b7_keccak_rotation_arr[var_7bd550b7_source_int]);
                }
            }
            for (var_7bd550b7_y_int = 0; var_7bd550b7_y_int < 5; var_7bd550b7_y_int += 1) {
                for (var_7bd550b7_x_int = 0; var_7bd550b7_x_int < 5; var_7bd550b7_x_int += 1) {
                    var var_7bd550b7_current_bigint = var_7bd550b7_b_arr[var_7bd550b7_x_int + (5 * var_7bd550b7_y_int)];
                    var var_7bd550b7_next_bigint = var_7bd550b7_b_arr[((var_7bd550b7_x_int + 1) % 5) + (5 * var_7bd550b7_y_int)];
                    var var_7bd550b7_next2_bigint = var_7bd550b7_b_arr[((var_7bd550b7_x_int + 2) % 5) + (5 * var_7bd550b7_y_int)];
                    var_7bd550b7_state_arr[var_7bd550b7_x_int + (5 * var_7bd550b7_y_int)] =
                        (var_7bd550b7_current_bigint ^ ((~var_7bd550b7_next_bigint) & var_7bd550b7_next2_bigint)) & var_7bd550b7_mask64_bigint;
                }
            }
            var_7bd550b7_state_arr[0] = (var_7bd550b7_state_arr[0] ^ var_7bd550b7_keccak_round_arr[var_7bd550b7_round_int]) & var_7bd550b7_mask64_bigint;
        }
    }

    function fun_7bd550b7_sha3_i1790129992_v1(var_7bd550b7_bytes_obj, var_7bd550b7_bits_int) {
        var var_7bd550b7_rate_int = var_7bd550b7_bits_int === 256 ? 136 : 72;
        var var_7bd550b7_output_int = var_7bd550b7_bits_int / 8;
        var var_7bd550b7_state_arr = new Array(25).fill(0n);
        var var_7bd550b7_padded_arr = Array.prototype.slice.call(var_7bd550b7_bytes_obj);
        var var_7bd550b7_offset_int = 0;
        var var_7bd550b7_lane_int = 0;
        var var_7bd550b7_byte_int = 0;
        var var_7bd550b7_value_bigint = 0n;
        var var_7bd550b7_result_arr = [];
        var_7bd550b7_padded_arr.push(0x06);
        while ((var_7bd550b7_padded_arr.length % var_7bd550b7_rate_int) !== (var_7bd550b7_rate_int - 1)) {
            var_7bd550b7_padded_arr.push(0x00);
        }
        var_7bd550b7_padded_arr.push(0x80);
        for (var_7bd550b7_offset_int = 0; var_7bd550b7_offset_int < var_7bd550b7_padded_arr.length; var_7bd550b7_offset_int += var_7bd550b7_rate_int) {
            for (var_7bd550b7_lane_int = 0; var_7bd550b7_lane_int < (var_7bd550b7_rate_int / 8); var_7bd550b7_lane_int += 1) {
                var_7bd550b7_value_bigint = 0n;
                for (var_7bd550b7_byte_int = 0; var_7bd550b7_byte_int < 8; var_7bd550b7_byte_int += 1) {
                    var_7bd550b7_value_bigint |= BigInt(var_7bd550b7_padded_arr[var_7bd550b7_offset_int + (var_7bd550b7_lane_int * 8) + var_7bd550b7_byte_int]) << BigInt(var_7bd550b7_byte_int * 8);
                }
                var_7bd550b7_state_arr[var_7bd550b7_lane_int] = (var_7bd550b7_state_arr[var_7bd550b7_lane_int] ^ var_7bd550b7_value_bigint) & var_7bd550b7_mask64_bigint;
            }
            fun_7bd550b7_keccak_f_i1790129991_v1(var_7bd550b7_state_arr);
        }
        while (var_7bd550b7_result_arr.length < var_7bd550b7_output_int) {
            for (var_7bd550b7_lane_int = 0; var_7bd550b7_lane_int < (var_7bd550b7_rate_int / 8) && var_7bd550b7_result_arr.length < var_7bd550b7_output_int; var_7bd550b7_lane_int += 1) {
                var_7bd550b7_value_bigint = var_7bd550b7_state_arr[var_7bd550b7_lane_int];
                for (var_7bd550b7_byte_int = 0; var_7bd550b7_byte_int < 8 && var_7bd550b7_result_arr.length < var_7bd550b7_output_int; var_7bd550b7_byte_int += 1) {
                    var_7bd550b7_result_arr.push(Number((var_7bd550b7_value_bigint >> BigInt(var_7bd550b7_byte_int * 8)) & 0xffn));
                }
            }
            if (var_7bd550b7_result_arr.length < var_7bd550b7_output_int) {
                fun_7bd550b7_keccak_f_i1790129991_v1(var_7bd550b7_state_arr);
            }
        }
        return new Uint8Array(var_7bd550b7_result_arr);
    }

    function fun_7bd550b7_rotate_left_32_i1790129993_v1(var_7bd550b7_value_int, var_7bd550b7_shift_int) {
        return ((var_7bd550b7_value_int << var_7bd550b7_shift_int) | (var_7bd550b7_value_int >>> (32 - var_7bd550b7_shift_int))) >>> 0;
    }

    function fun_7bd550b7_md5_i1790129994_v1(var_7bd550b7_bytes_obj) {
        var var_7bd550b7_s_arr = [7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21];
        var var_7bd550b7_k_arr = [];
        var var_7bd550b7_data_arr = Array.prototype.slice.call(var_7bd550b7_bytes_obj);
        var var_7bd550b7_bit_length_bigint = BigInt(var_7bd550b7_data_arr.length) * 8n;
        var var_7bd550b7_i_int = 0;
        var var_7bd550b7_offset_int = 0;
        var var_7bd550b7_m_arr = new Array(16);
        var var_7bd550b7_a0_int = 0x67452301;
        var var_7bd550b7_b0_int = 0xefcdab89;
        var var_7bd550b7_c0_int = 0x98badcfe;
        var var_7bd550b7_d0_int = 0x10325476;
        var var_7bd550b7_a_int = 0;
        var var_7bd550b7_b_int = 0;
        var var_7bd550b7_c_int = 0;
        var var_7bd550b7_d_int = 0;
        var var_7bd550b7_f_int = 0;
        var var_7bd550b7_g_int = 0;
        var var_7bd550b7_temp_int = 0;
        var var_7bd550b7_sum_int = 0;
        var var_7bd550b7_result_arr = [];
        for (var_7bd550b7_i_int = 0; var_7bd550b7_i_int < 64; var_7bd550b7_i_int += 1) {
            var_7bd550b7_k_arr.push(Math.floor(Math.abs(Math.sin(var_7bd550b7_i_int + 1)) * 4294967296) >>> 0);
        }
        var_7bd550b7_data_arr.push(0x80);
        while ((var_7bd550b7_data_arr.length % 64) !== 56) { var_7bd550b7_data_arr.push(0); }
        for (var_7bd550b7_i_int = 0; var_7bd550b7_i_int < 8; var_7bd550b7_i_int += 1) {
            var_7bd550b7_data_arr.push(Number((var_7bd550b7_bit_length_bigint >> BigInt(var_7bd550b7_i_int * 8)) & 0xffn));
        }
        for (var_7bd550b7_offset_int = 0; var_7bd550b7_offset_int < var_7bd550b7_data_arr.length; var_7bd550b7_offset_int += 64) {
            for (var_7bd550b7_i_int = 0; var_7bd550b7_i_int < 16; var_7bd550b7_i_int += 1) {
                var var_7bd550b7_base_int = var_7bd550b7_offset_int + (var_7bd550b7_i_int * 4);
                var_7bd550b7_m_arr[var_7bd550b7_i_int] = (var_7bd550b7_data_arr[var_7bd550b7_base_int] |
                    (var_7bd550b7_data_arr[var_7bd550b7_base_int + 1] << 8) |
                    (var_7bd550b7_data_arr[var_7bd550b7_base_int + 2] << 16) |
                    (var_7bd550b7_data_arr[var_7bd550b7_base_int + 3] << 24)) >>> 0;
            }
            var_7bd550b7_a_int = var_7bd550b7_a0_int;
            var_7bd550b7_b_int = var_7bd550b7_b0_int;
            var_7bd550b7_c_int = var_7bd550b7_c0_int;
            var_7bd550b7_d_int = var_7bd550b7_d0_int;
            for (var_7bd550b7_i_int = 0; var_7bd550b7_i_int < 64; var_7bd550b7_i_int += 1) {
                if (var_7bd550b7_i_int < 16) {
                    var_7bd550b7_f_int = (var_7bd550b7_b_int & var_7bd550b7_c_int) | ((~var_7bd550b7_b_int) & var_7bd550b7_d_int);
                    var_7bd550b7_g_int = var_7bd550b7_i_int;
                } else if (var_7bd550b7_i_int < 32) {
                    var_7bd550b7_f_int = (var_7bd550b7_d_int & var_7bd550b7_b_int) | ((~var_7bd550b7_d_int) & var_7bd550b7_c_int);
                    var_7bd550b7_g_int = ((5 * var_7bd550b7_i_int) + 1) % 16;
                } else if (var_7bd550b7_i_int < 48) {
                    var_7bd550b7_f_int = var_7bd550b7_b_int ^ var_7bd550b7_c_int ^ var_7bd550b7_d_int;
                    var_7bd550b7_g_int = ((3 * var_7bd550b7_i_int) + 5) % 16;
                } else {
                    var_7bd550b7_f_int = var_7bd550b7_c_int ^ (var_7bd550b7_b_int | (~var_7bd550b7_d_int));
                    var_7bd550b7_g_int = (7 * var_7bd550b7_i_int) % 16;
                }
                var_7bd550b7_temp_int = var_7bd550b7_d_int;
                var_7bd550b7_d_int = var_7bd550b7_c_int;
                var_7bd550b7_c_int = var_7bd550b7_b_int;
                var_7bd550b7_sum_int = (var_7bd550b7_a_int + var_7bd550b7_f_int + var_7bd550b7_k_arr[var_7bd550b7_i_int] + var_7bd550b7_m_arr[var_7bd550b7_g_int]) >>> 0;
                var_7bd550b7_b_int = (var_7bd550b7_b_int + fun_7bd550b7_rotate_left_32_i1790129993_v1(var_7bd550b7_sum_int, var_7bd550b7_s_arr[var_7bd550b7_i_int])) >>> 0;
                var_7bd550b7_a_int = var_7bd550b7_temp_int;
            }
            var_7bd550b7_a0_int = (var_7bd550b7_a0_int + var_7bd550b7_a_int) >>> 0;
            var_7bd550b7_b0_int = (var_7bd550b7_b0_int + var_7bd550b7_b_int) >>> 0;
            var_7bd550b7_c0_int = (var_7bd550b7_c0_int + var_7bd550b7_c_int) >>> 0;
            var_7bd550b7_d0_int = (var_7bd550b7_d0_int + var_7bd550b7_d_int) >>> 0;
        }
        [var_7bd550b7_a0_int, var_7bd550b7_b0_int, var_7bd550b7_c0_int, var_7bd550b7_d0_int].forEach(function (var_7bd550b7_word_int) {
            var var_7bd550b7_j_int = 0;
            for (var_7bd550b7_j_int = 0; var_7bd550b7_j_int < 4; var_7bd550b7_j_int += 1) {
                var_7bd550b7_result_arr.push((var_7bd550b7_word_int >>> (var_7bd550b7_j_int * 8)) & 0xff);
            }
        });
        return new Uint8Array(var_7bd550b7_result_arr);
    }

    function fun_7bd550b7_crc32_i1790129995_v1(var_7bd550b7_bytes_obj) {
        var var_7bd550b7_crc_int = 0xffffffff;
        var var_7bd550b7_i_int = 0;
        var var_7bd550b7_j_int = 0;
        for (var_7bd550b7_i_int = 0; var_7bd550b7_i_int < var_7bd550b7_bytes_obj.length; var_7bd550b7_i_int += 1) {
            var_7bd550b7_crc_int = (var_7bd550b7_crc_int ^ var_7bd550b7_bytes_obj[var_7bd550b7_i_int]) >>> 0;
            for (var_7bd550b7_j_int = 0; var_7bd550b7_j_int < 8; var_7bd550b7_j_int += 1) {
                if ((var_7bd550b7_crc_int & 1) !== 0) {
                    var_7bd550b7_crc_int = ((var_7bd550b7_crc_int >>> 1) ^ 0xedb88320) >>> 0;
                } else {
                    var_7bd550b7_crc_int = (var_7bd550b7_crc_int >>> 1) >>> 0;
                }
            }
        }
        return (var_7bd550b7_crc_int ^ 0xffffffff) >>> 0;
    }

    function fun_7bd550b7_bytes_to_hex_i1790129996_v1(var_7bd550b7_bytes_obj) {
        var var_7bd550b7_result_str = "";
        var var_7bd550b7_i_int = 0;
        for (var_7bd550b7_i_int = 0; var_7bd550b7_i_int < var_7bd550b7_bytes_obj.length; var_7bd550b7_i_int += 1) {
            var_7bd550b7_result_str += var_7bd550b7_bytes_obj[var_7bd550b7_i_int].toString(16).padStart(2, "0");
        }
        return var_7bd550b7_result_str;
    }

    function fun_7bd550b7_digest_native_i1790129997_v1(var_7bd550b7_name_str, var_7bd550b7_bytes_obj) {
        if (!window.crypto || !window.crypto.subtle) {
            return Promise.reject(new Error("Web Crypto is unavailable in this browser context."));
        }
        return window.crypto.subtle.digest(var_7bd550b7_name_str, var_7bd550b7_bytes_obj).then(function (var_7bd550b7_buffer_obj) {
            return fun_7bd550b7_bytes_to_hex_i1790129996_v1(new Uint8Array(var_7bd550b7_buffer_obj));
        });
    }

    function fun_7bd550b7_set_result_i1790129998_v1(var_7bd550b7_id_str, var_7bd550b7_value_str) {
        var var_7bd550b7_target_obj = document.getElementById(var_7bd550b7_id_str);
        if (var_7bd550b7_target_obj !== null) { var_7bd550b7_target_obj.textContent = var_7bd550b7_value_str; }
    }

    function fun_7bd550b7_hash_string_i1790129999_v1() {
        var var_7bd550b7_input_obj = document.getElementById("hash_string_input");
        var var_7bd550b7_status_obj = document.getElementById("hash_string_status");
        var var_7bd550b7_bytes_obj = new TextEncoder().encode(var_7bd550b7_input_obj.value);
        var var_7bd550b7_crc_int = fun_7bd550b7_crc32_i1790129995_v1(var_7bd550b7_bytes_obj);
        var_7bd550b7_status_obj.textContent = "Hashing...";
        var_7bd550b7_status_obj.setAttribute("data-state", "");
        fun_7bd550b7_set_result_i1790129998_v1("hash_sha3_512", fun_7bd550b7_bytes_to_hex_i1790129996_v1(fun_7bd550b7_sha3_i1790129992_v1(var_7bd550b7_bytes_obj, 512)));
        fun_7bd550b7_set_result_i1790129998_v1("hash_sha3_256", fun_7bd550b7_bytes_to_hex_i1790129996_v1(fun_7bd550b7_sha3_i1790129992_v1(var_7bd550b7_bytes_obj, 256)));
        fun_7bd550b7_set_result_i1790129998_v1("hash_md5", fun_7bd550b7_bytes_to_hex_i1790129996_v1(fun_7bd550b7_md5_i1790129994_v1(var_7bd550b7_bytes_obj)));
        fun_7bd550b7_set_result_i1790129998_v1("hash_crc32", var_7bd550b7_crc_int.toString(16).padStart(8, "0"));
        Promise.all([
            fun_7bd550b7_digest_native_i1790129997_v1("SHA-256", var_7bd550b7_bytes_obj),
            fun_7bd550b7_digest_native_i1790129997_v1("SHA-512", var_7bd550b7_bytes_obj),
            fun_7bd550b7_digest_native_i1790129997_v1("SHA-1", var_7bd550b7_bytes_obj)
        ]).then(function (var_7bd550b7_native_arr) {
            fun_7bd550b7_set_result_i1790129998_v1("hash_sha_256", var_7bd550b7_native_arr[0]);
            fun_7bd550b7_set_result_i1790129998_v1("hash_sha_512", var_7bd550b7_native_arr[1]);
            fun_7bd550b7_set_result_i1790129998_v1("hash_sha_1", var_7bd550b7_native_arr[2]);
            var_7bd550b7_status_obj.textContent = "Hashes generated.";
            var_7bd550b7_status_obj.setAttribute("data-state", "success");
        }).catch(function (var_7bd550b7_error_obj) {
            fun_7bd550b7_set_result_i1790129998_v1("hash_sha_256", "Unavailable");
            fun_7bd550b7_set_result_i1790129998_v1("hash_sha_512", "Unavailable");
            fun_7bd550b7_set_result_i1790129998_v1("hash_sha_1", "Unavailable");
            var_7bd550b7_status_obj.textContent = var_7bd550b7_error_obj.message || "Native browser hashing is unavailable.";
            var_7bd550b7_status_obj.setAttribute("data-state", "error");
        });
    }


    function fun_7bd550b7_copy_hash_i1790130043_v1(var_7bd550b7_event_obj) {
        var var_7bd550b7_button_obj = var_7bd550b7_event_obj.currentTarget;
        var var_7bd550b7_target_obj = document.getElementById(var_7bd550b7_button_obj.getAttribute("data-copy-target"));
        var var_7bd550b7_status_obj = document.getElementById("hash_string_status");
        var var_7bd550b7_label_str = var_7bd550b7_button_obj.getAttribute("data-copy-label") || "Checksum";
        var var_7bd550b7_value_str = var_7bd550b7_target_obj === null ? "" : var_7bd550b7_target_obj.textContent;
        if (var_7bd550b7_value_str === "") { return; }
        window.RitcheyClipboard.copyText(var_7bd550b7_value_str, function () {
            var_7bd550b7_status_obj.textContent = var_7bd550b7_label_str + " checksum copied to the clipboard.";
            var_7bd550b7_status_obj.setAttribute("data-state", "success");
        }, function () {
            var_7bd550b7_status_obj.textContent = "Copy was blocked by the browser.";
            var_7bd550b7_status_obj.setAttribute("data-state", "error");
        });
    }

    function fun_7bd550b7_initialize_i1790130000_v2() {
        var var_7bd550b7_button_obj = document.getElementById("hash_string_submit");
        var var_7bd550b7_copy_buttons_obj = document.querySelectorAll(".hash_copy_button");
        var var_7bd550b7_copy_index_int = 0;
        if (var_7bd550b7_button_obj !== null) {
            var_7bd550b7_button_obj.addEventListener("click", fun_7bd550b7_hash_string_i1790129999_v1);
        }
        while (var_7bd550b7_copy_index_int < var_7bd550b7_copy_buttons_obj.length) {
            var_7bd550b7_copy_buttons_obj[var_7bd550b7_copy_index_int].addEventListener("click", fun_7bd550b7_copy_hash_i1790130043_v1);
            var_7bd550b7_copy_index_int += 1;
        }
    }

    window.RitcheyHashStrings = {
        sha3: fun_7bd550b7_sha3_i1790129992_v1,
        md5: fun_7bd550b7_md5_i1790129994_v1,
        crc32: fun_7bd550b7_crc32_i1790129995_v1,
        bytesToHex: fun_7bd550b7_bytes_to_hex_i1790129996_v1
    };

    if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", fun_7bd550b7_initialize_i1790130000_v2); }
    else { fun_7bd550b7_initialize_i1790130000_v2(); }
}());
